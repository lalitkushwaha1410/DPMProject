package testCases;

import org.testng.annotations.Test;

import Base.PageBaseclass;
import Pages.DPM_ProjectSummaryPage;
import Pages.LoginPage;
import Pages.homePage_3DExp;

public class LoginTest {
	

	@Test
	public void loginTest() throws InterruptedException  {

	/*	WebDriverManager.chromedriver().setup();
		// WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://vdevpril756plp.dsone.3ds.com:453/iam/cas/login?serverId&service=https%3A//vdevpril756plp.dsone.3ds.com%3A444/3DDashboard/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		*/
		
		PageBaseclass.initConfiguration();

		LoginPage login1 = new LoginPage();
		login1.dologin("devleader1", "Passport1");  //doing the login 
		
		Thread.sleep(5000);

		homePage_3DExp home3dexp1 = new homePage_3DExp(); 
		home3dexp1.compass_north_Quadrant();   //navigating to the 3dexperience page
		
		Thread.sleep(3000);
		
		
		DPM_ProjectSummaryPage projpage = new DPM_ProjectSummaryPage();
		projpage.gotoPrograms();   // clicking on programs
		
		
		PageBaseclass.teadDown();  //closing the browser
		
		

	}

}
