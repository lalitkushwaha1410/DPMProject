package rough;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import Pages.LoginPage;
import Pages.homePage_3DExp;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginTest {

	public static void main(String[] args) throws InterruptedException {

		WebDriverManager.chromedriver().setup();
		//WebDriverManager.firefoxdriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://vdevpril756plp.dsone.3ds.com:453/iam/cas/login?serverId&service=https%3A//vdevpril756plp.dsone.3ds.com%3A444/3DDashboard/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		Thread.sleep(3000);

		LoginPage login = new LoginPage(driver);
		login.dologin("lka2lead2", "Passport1");
		
		homePage_3DExp home3dexp = new homePage_3DExp(driver);
		home3dexp.compass_north_Quadrant();

	}

}
