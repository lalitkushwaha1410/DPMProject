package Base;

public class Constants {

	
	
	public static final String browser="chrome";
	
	public static final String url = "https://vdevpril990plp.dsone.3ds.com:453/iam/login?service=https%3A%2F%2Fvdevpril990plp.dsone.3ds.com%2F3DSpace%2F";
	
	
}
