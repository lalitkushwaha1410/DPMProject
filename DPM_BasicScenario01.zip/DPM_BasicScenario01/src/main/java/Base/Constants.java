package Base;

public class Constants {

	
	
	public static final String browser="chrome";
	
	public static final String url = "https://vdevpril756plp.dsone.3ds.com:453/iam/cas/login?serverId&service=https%3A//vdevpril756plp.dsone.3ds.com%3A444/3DDashboard/";
	
	
}
