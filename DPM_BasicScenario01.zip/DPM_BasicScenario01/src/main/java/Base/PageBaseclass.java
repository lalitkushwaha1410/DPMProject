package Base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.logging.Log;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PageBaseclass {
	
	/*static WebDriver driver;
	static Properties prop;
	
	public pageBaseclass() {
		
		prop=new Properties();
		
		try {
			FileInputStream fis = new FileInputStream("C:/Users/lka2/eclipse-workspace2019/DPM_BasicScenario01/OR.Properties");
				prop.load(fis);
			} 
		
		catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		*/
	
	public static WebDriver driver;
	public static Logger log =Logger.getLogger("test-logs");
	
	public static void initConfiguration()
	{
		
	if(Constants.browser.equalsIgnoreCase("firefox"))
	{
		
		WebDriverManager.firefoxdriver().setup();
		log.info("launching firefox");
		driver = new FirefoxDriver();
	}
	
	else if(Constants.browser.equalsIgnoreCase("chrome"))
	{
		WebDriverManager.chromedriver().setup();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 2);
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("--disable-extensions");
		options.addArguments("--disable-infobars");

		driver = new ChromeDriver(options);
		log.info("launching chrome");
	}
	
	
	driver.get(Constants.url);
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS );
	

	}
		
}
