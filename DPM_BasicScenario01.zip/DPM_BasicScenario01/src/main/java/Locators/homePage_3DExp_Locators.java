package Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class homePage_3DExp_Locators {
	
	@FindBy (xpath="//div[@id='compass_ctn']/div/div[1]/div[1]")
	public WebElement north_quad;
	
	@FindBy (css="li:nth-of-type(3) > .expand-img.fonticon")
	public WebElement arrow;
	
	@FindBy (xpath="/html//img[@id='icon-ENOPRPR_AP']")
	public WebElement DPM_chichlet;
	

}



