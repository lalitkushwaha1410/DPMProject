package Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class homePage_3DExp_Locators {
	
	@FindBy (xpath="//div[@id='compass_ctn']/div/div[1]/div[1]")
	public WebElement north_quad;
	
	//li:nth-of-type(3) > .expand-img.fonticon
	
	@FindBy (css="[data-id='DPMtrue']")
	public WebElement arrow;
	
	@FindBy (xpath="//li[@class='exp-item drag-app']//div[@class='title'][contains(text(),'Project Management')]")
	public WebElement DPM_chichlet;
	

}



