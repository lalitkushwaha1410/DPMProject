package Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class loginPage_Locators {
	
	
	@FindBy (css="input[name='username']")
	public WebElement logintxt;
	
	@FindBy (css="input[name='password']")
	public WebElement passwordtxt;
	
	@FindBy (css=".uwa-submit-submit")
	public WebElement submitbtn;

}
