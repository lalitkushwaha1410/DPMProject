package Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DPM_ProjectSummaryPage_Locators {
	
	
	@FindBy (css="div#PMCMyDesk  ul > li:nth-of-type(2) > a > label")
	public WebElement programs;

}
