package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Base.PageBaseclass;
import Locators.homePage_3DExp_Locators;
import Locators.loginPage_Locators;

public class homePage_3DExp extends PageBaseclass{

public homePage_3DExp_Locators home ;
	
	public homePage_3DExp () {
		
		this.home=new homePage_3DExp_Locators();
		PageFactory.initElements(driver, this.home);
	}

	public DPM_TaskSummaryPage compass_north_Quadrant() throws InterruptedException {

		home.north_quad.click();

		Thread.sleep(4000);

		home.arrow.click();

		Thread.sleep(3000);

		home.DPM_chichlet.click();
		
		return new DPM_TaskSummaryPage();
	}

}
