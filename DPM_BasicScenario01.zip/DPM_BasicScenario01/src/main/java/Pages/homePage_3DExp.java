package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class homePage_3DExp {
	
WebDriver driver;
	
	public homePage_3DExp (WebDriver driver) {
		
		this.driver=driver;
	}
	
	public void compass_north_Quadrant() throws InterruptedException {
		
		WebElement north_quad = driver.findElement(By.xpath("//div[@id='compass_ctn']/div/div[1]/div[1]"));
		north_quad.click();
		
		Thread.sleep(4000);
		
		
		
		
		WebElement arrow =driver.findElement(By.cssSelector("li:nth-of-type(3) > .expand-img.fonticon"));
		arrow.click();
		
		Thread.sleep(3000);
		
		WebElement DPM_chichlet =driver.findElement(By.xpath("/html//img[@id='icon-ENOPRPR_AP']"));
	
		DPM_chichlet.click();
	}
	

}
