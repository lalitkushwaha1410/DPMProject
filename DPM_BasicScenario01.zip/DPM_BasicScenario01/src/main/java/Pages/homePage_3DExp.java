package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Base.PageBaseclass;
import Locators.homePage_3DExp_Locators;
import Locators.loginPage_Locators;

public class homePage_3DExp extends PageBaseclass{

public homePage_3DExp_Locators home ;
	
	public homePage_3DExp () {
		
		this.home=new homePage_3DExp_Locators();
		PageFactory.initElements(driver, this.home);
	}

	public DPM_ProjectSummaryPage compass_north_Quadrant() throws InterruptedException {
		
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector(".ds-coachmark-close")).click();

		home.north_quad.click();

		Thread.sleep(3000);

		home.arrow.click();

		Thread.sleep(2000);
		
		
		if (home.DPM_chichlet.isDisplayed()) {
			
			home.DPM_chichlet.click();
		}
		else {
			
			home.arrow.click();
			home.DPM_chichlet.click();
			Thread.sleep(3000);
		}

		driver.findElement(By.cssSelector(".ds-coachmark-close")).click();
		
		return new DPM_ProjectSummaryPage();
	}

}
