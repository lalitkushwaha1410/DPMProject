package Pages;

import org.openqa.selenium.support.PageFactory;

import Base.PageBaseclass;
import Locators.loginPage_Locators;

public class LoginPage extends PageBaseclass {

	public loginPage_Locators login ;
	
	public LoginPage () {
		
		this.login=new loginPage_Locators();
		PageFactory.initElements(driver, this.login);
	}
	
	
	public homePage_3DExp dologin(String un,String pwd) throws InterruptedException {
		
		login.logintxt.sendKeys(un);
		
		login.passwordtxt.sendKeys(pwd);
	
		login.submitbtn.click();
		
		Thread.sleep(5000);
		
		return new homePage_3DExp();
	}
	
	
	public void doRegsitration() {
		
	}


	
	
}
