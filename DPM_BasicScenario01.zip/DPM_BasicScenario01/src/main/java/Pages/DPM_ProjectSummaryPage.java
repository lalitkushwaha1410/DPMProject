package Pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import Base.PageBaseclass;
import Locators.DPM_ProjectSummaryPage_Locators;

public class DPM_ProjectSummaryPage extends PageBaseclass {

public DPM_ProjectSummaryPage_Locators summarypage ;
	
	public DPM_ProjectSummaryPage () {
		
		this.summarypage=new DPM_ProjectSummaryPage_Locators();
		PageFactory.initElements(driver, this.summarypage);
	}
	
	
	public void gotoPrograms() throws InterruptedException {
		
		
		summarypage.programs.click();
		Thread.sleep(3000);
		
	}
	
	
	public void gotoBusinessGoals()
	{
		
		
		
	}
	
	public void gotoProjectTemplates() {
		
	}

	
	public void gotoProjects() {
		
	}
	
	
	
	
	
}
