package Pages;

public class DPM_TaskSummaryPage {

	
	public void gotoBusinessGoals()
	{
		
	}
	
	public void gotoProjectTemplates() {
		
	}

	
	public void gotoProjects() {
		
	}
	
	public void gotoPrograms() {
		
	}
	
	
	
}
